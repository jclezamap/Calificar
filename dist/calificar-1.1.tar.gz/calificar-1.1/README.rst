calificar
=========

.. image:: https://img.shields.io/pypi/v/calificar.svg
    :target: https://pypi.python.org/pypi/calificar
    :alt: Latest PyPI version

.. image:: https://travis-ci.org/kragniz/cookiecutter-pypackage-minimal.png
   :target: https://travis-ci.org/kragniz/cookiecutter-pypackage-minimal
   :alt: Latest Travis CI build status

An opinionated, minimal cookiecutter template for Python packages

Usage
-----

Installation
------------

Requirements
^^^^^^^^^^^^

Compatibility
-------------

Licence
-------

Authors
-------

`calificar` was written by `Juan Carlos Lezama <jclezamap@gmail.com>`_.
