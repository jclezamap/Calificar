"""calificar - An opinionated, minimal cookiecutter template for Python packages"""

__version__ = '1.1'
__author__ = 'Juan Carlos Lezama <jclezamap@gmail.com>'
__all__ = []


